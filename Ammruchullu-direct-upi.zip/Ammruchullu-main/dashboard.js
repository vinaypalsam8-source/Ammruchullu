/**
 * Amma Ruchulu - Store Owner Admin Dashboard Engine
 * Real-time Order Tracking, Status Updates, Revenue Analytics, and WhatsApp Dispatch
 */

let dashboardState = {
  orders: [],
  currentFilter: "all",
  searchQuery: ""
};

// Initial Sample Orders for immediate store management demo
const INITIAL_SEED_ORDERS = [
  {
    orderId: "AR-2026-8921",
    timestamp: "29/08/2026, 08:30:15 pm",
    orderStatus: "completed",
    customer: {
      fullName: "Suresh Kumar",
      phone: "9848022338",
      email: "suresh.k@gmail.com",
      streetAddress: "Flat 302, Sri Sai Residency, Road No 2",
      landmark: "Near Hanuman Temple, Parvathapur",
      pincode: "500098",
      utr: "N/A"
    },
    items: [
      { id: "mango-pickle", name: "Avakaya Mango Pickle", weight: "500g", unitPrice: 230, quantity: 2 },
      { id: "chicken-pickle", name: "Andhra Chicken Pickle (Boneless)", weight: "500g", unitPrice: 420, quantity: 1 }
    ],
    totals: { subtotal: 880, discountAmount: 0, deliveryFee: 0, grandTotal: 880 },
    paymentMode: "upi",
    status: "UPI Paid (UTR: 423984719283)"
  },
  {
    orderId: "AR-2026-7842",
    timestamp: "29/08/2026, 07:15:20 pm",
    orderStatus: "processing",
    customer: {
      fullName: "Lakshmi Narayana",
      phone: "9876543210",
      email: "lakshmi.n@yahoo.com",
      streetAddress: "Plot 45, Sai Aishwarya Colony, Road No 1",
      landmark: "Near Mediplus Pharmacy",
      pincode: "500098",
      utr: "N/A"
    },
    items: [
      { id: "mutton-pickle", name: "Royal Mutton Pickle (Boneless)", weight: "1kg", unitPrice: 1300, quantity: 1 },
      { id: "lemon-pickle", name: "Tangy Lemon Pickle", weight: "500g", unitPrice: 190, quantity: 1 }
    ],
    totals: { subtotal: 1490, discountAmount: 149, deliveryFee: 0, grandTotal: 1341 },
    paymentMode: "cod",
    status: "Cash on Delivery (Pay upon receipt)"
  },
  {
    orderId: "AR-2026-6519",
    timestamp: "29/08/2026, 06:40:10 pm",
    orderStatus: "pending",
    customer: {
      fullName: "Anand Rao",
      phone: "9440123456",
      email: "anand.rao@outlook.com",
      streetAddress: "House No 4-12/1, Boduppal Main Road",
      landmark: "Opposite More Supermarket, Peerzadiguda",
      pincode: "500039",
      utr: "N/A"
    },
    items: [
      { id: "usirikaya-pickle", name: "Usirikaya (Amla) Pickle", weight: "500g", unitPrice: 250, quantity: 2 },
      { id: "mango-pickle", name: "Avakaya Mango Pickle", weight: "1kg", unitPrice: 440, quantity: 1 }
    ],
    totals: { subtotal: 940, discountAmount: 0, deliveryFee: 0, grandTotal: 940 },
    paymentMode: "cod",
    status: "Cash on Delivery (Pay upon receipt)"
  }
];

// Initialize Dashboard
document.addEventListener("DOMContentLoaded", () => {
  loadOrders();
  renderDashboard();
  if (window.lucide) {
    window.lucide.createIcons();
  }
});

// Load Orders from LocalStorage (or Seed if empty)
function loadOrders() {
  try {
    const raw = localStorage.getItem("amma_ruchulu_all_orders");
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed) && parsed.length > 0) {
        dashboardState.orders = parsed.map(order => ({
          ...order,
          orderStatus: order.orderStatus || (order.status && order.status.toLowerCase().includes("delivered") ? "completed" : "pending")
        }));
        return;
      }
    }
  } catch (e) {
    console.error("Error reading orders from localStorage", e);
  }

  // Seed default sample orders for immediate demonstration
  dashboardState.orders = [...INITIAL_SEED_ORDERS];
  saveOrdersToStorage();
}

function saveOrdersToStorage() {
  try {
    localStorage.setItem("amma_ruchulu_all_orders", JSON.stringify(dashboardState.orders));
  } catch (e) {
    console.error("Error saving orders", e);
  }
}

// Add sample orders manually
function seedSampleOrders() {
  const newOrder = {
    orderId: `AR-2026-${Math.floor(1000 + Math.random() * 9000)}`,
    timestamp: new Date().toLocaleString("en-IN", { timeZone: "Asia/Kolkata" }),
    orderStatus: "pending",
    customer: {
      fullName: "Ramesh Reddy",
      phone: "8341643180",
      email: "customer@gmail.com",
      streetAddress: "Sai Aishwarya Colony, Road No 1, Parvathapur",
      landmark: "Near Mediplus",
      pincode: "500098",
      utr: "N/A"
    },
    items: [
      { id: "mango-pickle", name: "Avakaya Mango Pickle", weight: "500g", unitPrice: 230, quantity: 1 },
      { id: "chicken-pickle", name: "Andhra Chicken Pickle (Boneless)", weight: "500g", unitPrice: 420, quantity: 1 }
    ],
    totals: { subtotal: 650, discountAmount: 65, deliveryFee: 0, grandTotal: 585 },
    paymentMode: "cod",
    status: "Cash on Delivery (Pay upon receipt)"
  };

  dashboardState.orders.unshift(newOrder);
  saveOrdersToStorage();
  renderDashboard();
  showDashboardToast(`Sample Order #${newOrder.orderId} added!`);
}

// Refresh Data
function refreshDashboardData() {
  loadOrders();
  renderDashboard();
  showDashboardToast("Dashboard refreshed with latest orders!");
}

// Set Status Filter
function setStatusFilter(filter) {
  dashboardState.currentFilter = filter;
  
  // Update Tab Styling
  document.querySelectorAll(".status-tab-btn").forEach(btn => {
    const isTarget = btn.getAttribute("data-filter") === filter;
    if (isTarget) {
      btn.className = "status-tab-btn active px-3.5 py-2 rounded-xl text-xs font-bold bg-amber-500 text-neutral-950 transition";
    } else {
      btn.className = "status-tab-btn px-3.5 py-2 rounded-xl text-xs font-bold bg-neutral-900 hover:bg-neutral-800 text-neutral-300 border border-neutral-700 transition";
    }
  });

  renderOrdersTable();
}

// Handle Search
function handleSearch(query) {
  dashboardState.searchQuery = query.trim().toLowerCase();
  renderOrdersTable();
}

// Update Order Status (Pending -> Processing -> Completed -> Cancelled)
function updateOrderStatus(orderId, newStatus) {
  const order = dashboardState.orders.find(o => o.orderId === orderId);
  if (order) {
    order.orderStatus = newStatus;
    saveOrdersToStorage();
    renderKPIs();
    renderOrdersTable();
    showDashboardToast(`Order #${orderId} marked as ${newStatus.toUpperCase()}`);
  }
}

// Delete Order
function deleteOrder(orderId) {
  if (confirm(`Are you sure you want to delete order #${orderId}?`)) {
    dashboardState.orders = dashboardState.orders.filter(o => o.orderId !== orderId);
    saveOrdersToStorage();
    renderDashboard();
    showDashboardToast(`Order #${orderId} deleted.`);
  }
}

// Render Complete Dashboard
function renderDashboard() {
  renderKPIs();
  renderOrdersTable();
}

// Render KPI Stats Cards
function renderKPIs() {
  const total = dashboardState.orders.length;
  const pending = dashboardState.orders.filter(o => (o.orderStatus || "pending") === "pending").length;
  const processing = dashboardState.orders.filter(o => o.orderStatus === "processing").length;
  const completed = dashboardState.orders.filter(o => o.orderStatus === "completed").length;
  const cancelled = dashboardState.orders.filter(o => o.orderStatus === "cancelled").length;

  const totalRevenue = dashboardState.orders
    .filter(o => o.orderStatus !== "cancelled")
    .reduce((sum, o) => sum + (o.totals?.grandTotal || 0), 0);

  document.getElementById("kpi-total-orders").textContent = total;
  document.getElementById("kpi-pending-orders").textContent = pending;
  document.getElementById("kpi-processing-orders").textContent = processing;
  document.getElementById("kpi-completed-orders").textContent = completed;
  document.getElementById("kpi-total-revenue").textContent = `₹${totalRevenue.toLocaleString("en-IN")}`;

  // Update tab counts
  document.getElementById("count-tab-all").textContent = total;
  document.getElementById("count-tab-pending").textContent = pending;
  document.getElementById("count-tab-processing").textContent = processing;
  document.getElementById("count-tab-completed").textContent = completed;
  document.getElementById("count-tab-cancelled").textContent = cancelled;
}

// Render Orders Table
function renderOrdersTable() {
  const tbody = document.getElementById("orders-table-body");
  const emptyState = document.getElementById("empty-state");
  if (!tbody) return;

  // Filter Orders
  let filtered = dashboardState.orders;

  if (dashboardState.currentFilter !== "all") {
    filtered = filtered.filter(o => (o.orderStatus || "pending") === dashboardState.currentFilter);
  }

  if (dashboardState.searchQuery) {
    const q = dashboardState.searchQuery;
    filtered = filtered.filter(o => {
      const matchId = o.orderId.toLowerCase().includes(q);
      const matchName = o.customer.fullName.toLowerCase().includes(q);
      const matchPhone = o.customer.phone.toLowerCase().includes(q);
      const matchAddress = o.customer.streetAddress.toLowerCase().includes(q);
      const matchItems = o.items.some(i => i.name.toLowerCase().includes(q));
      return matchId || matchName || matchPhone || matchAddress || matchItems;
    });
  }

  if (filtered.length === 0) {
    tbody.innerHTML = "";
    emptyState.classList.remove("hidden");
    return;
  }

  emptyState.classList.add("hidden");

  tbody.innerHTML = filtered.map(order => {
    const status = order.orderStatus || "pending";
    const paymentMode = order.paymentMode || "cod";
    const phoneClean = order.customer.phone.replace(/[^0-9]/g, "");

    // Status Badge Color Map
    const statusBadgeClasses = {
      pending: "bg-amber-500/20 text-amber-300 border-amber-500/40",
      processing: "bg-sky-500/20 text-sky-300 border-sky-500/40",
      completed: "bg-emerald-500/20 text-emerald-300 border-emerald-500/40",
      cancelled: "bg-rose-500/20 text-rose-300 border-rose-500/40"
    };

    // Payment Mode Badges
    const paymentBadgeClasses = {
      cod: "bg-amber-500/20 text-amber-300",
      upi: "bg-emerald-500/20 text-emerald-300",
      credit: "bg-purple-500/20 text-purple-300",
      debit: "bg-blue-500/20 text-blue-300"
    };

    const itemsSummary = order.items.map(i => `
      <div class="flex items-center gap-1.5 text-xs text-neutral-200">
        <span class="w-1.5 h-1.5 rounded-full bg-amber-400"></span>
        <span class="font-semibold">${i.name}</span>
        <span class="px-1.5 py-0.2 bg-neutral-800 text-amber-300 rounded text-[10px] font-bold">${i.weight}</span>
        <span class="text-neutral-400">x${i.quantity}</span>
        <span class="text-amber-200/80 font-mono text-[11px]">₹${i.unitPrice * i.quantity}</span>
      </div>
    `).join("");

    return `
      <tr class="hover:bg-neutral-900/60 transition duration-150">
        
        <!-- 1. Order ID & Date -->
        <td class="py-4 px-4 align-top">
          <span class="font-mono font-bold text-amber-400 block text-xs">${order.orderId}</span>
          <span class="text-[11px] text-neutral-500 block mt-0.5">${order.timestamp}</span>
        </td>

        <!-- 2. Customer & Contact -->
        <td class="py-4 px-4 align-top">
          <span class="font-bold text-white block">${order.customer.fullName}</span>
          <a href="tel:${phoneClean}" class="text-[11px] text-amber-400/90 hover:underline flex items-center gap-1 mt-0.5 font-mono">
            📞 ${order.customer.phone}
          </a>
        </td>

        <!-- 3. Delivery Address -->
        <td class="py-4 px-4 align-top max-w-xs">
          <p class="text-xs text-neutral-300 leading-snug line-clamp-2">${order.customer.streetAddress}</p>
          <span class="text-[10px] text-neutral-500 block mt-0.5">${order.customer.landmark || "Parvathapur"} • ${order.customer.pincode || "500098"}</span>
        </td>

        <!-- 4. Pickles Ordered -->
        <td class="py-4 px-4 align-top">
          <div class="space-y-1">
            ${itemsSummary}
          </div>
        </td>

        <!-- 5. Bill & Payment -->
        <td class="py-4 px-4 align-top">
          <span class="text-sm font-black text-amber-300 font-mono block">₹${order.totals.grandTotal}</span>
          <span class="inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider mt-1 ${paymentBadgeClasses[paymentMode] || 'bg-neutral-800 text-neutral-300'}">
            ${paymentMode.toUpperCase()}
          </span>
          ${order.customer.utr && order.customer.utr !== "N/A" ? `<span class="block text-[9px] text-neutral-400 font-mono mt-0.5">UTR: ${order.customer.utr}</span>` : ''}
        </td>

        <!-- 6. Status Selector -->
        <td class="py-4 px-4 align-top">
          <select 
            onchange="updateOrderStatus('${order.orderId}', this.value)"
            class="px-2.5 py-1.5 rounded-xl text-xs font-bold border transition cursor-pointer bg-neutral-900 ${statusBadgeClasses[status] || statusBadgeClasses.pending}"
          >
            <option value="pending" ${status === 'pending' ? 'selected' : ''} class="bg-neutral-900 text-amber-300">⏳ Pending</option>
            <option value="processing" ${status === 'processing' ? 'selected' : ''} class="bg-neutral-900 text-sky-300">🍳 Preparing</option>
            <option value="completed" ${status === 'completed' ? 'selected' : ''} class="bg-neutral-900 text-emerald-300">✅ Completed</option>
            <option value="cancelled" ${status === 'cancelled' ? 'selected' : ''} class="bg-neutral-900 text-rose-300">❌ Cancelled</option>
          </select>
        </td>

        <!-- 7. Actions -->
        <td class="py-4 px-4 align-top text-center">
          <div class="flex items-center justify-center gap-1.5">
            
            <!-- WhatsApp Customer Button -->
            <button 
              onclick="notifyCustomerWhatsApp('${order.orderId}')"
              class="p-2 rounded-xl bg-emerald-600/20 hover:bg-emerald-600 text-emerald-300 hover:text-white transition shadow-sm"
              title="Send WhatsApp Update to Customer"
            >
              <i data-lucide="message-circle" class="w-4 h-4"></i>
            </button>

            <!-- Print Kitchen Slip -->
            <button 
              onclick="openKitchenSlipModal('${order.orderId}')"
              class="p-2 rounded-xl bg-amber-500/20 hover:bg-amber-500 text-amber-300 hover:text-neutral-950 transition shadow-sm"
              title="Print Kitchen Preparation Slip"
            >
              <i data-lucide="printer" class="w-4 h-4"></i>
            </button>

            <!-- Delete Order -->
            <button 
              onclick="deleteOrder('${order.orderId}')"
              class="p-2 rounded-xl bg-rose-500/10 hover:bg-rose-600 text-rose-400 hover:text-white transition"
              title="Delete Order"
            >
              <i data-lucide="trash-2" class="w-4 h-4"></i>
            </button>

          </div>
        </td>

      </tr>
    `;
  }).join("");

  if (window.lucide) {
    window.lucide.createIcons();
  }
}

// WhatsApp Customer Notification Dispatch
function notifyCustomerWhatsApp(orderId) {
  const order = dashboardState.orders.find(o => o.orderId === orderId);
  if (!order) return;

  const phone = order.customer.phone.replace(/[^0-9]/g, "");
  const targetPhone = phone.startsWith("91") ? phone : `91${phone}`;

  let statusMsg = "Your homemade pickles are being prepared with love! ❤️🍛";
  if (order.orderStatus === "completed") {
    statusMsg = "Your order has been DELIVERED! Thank you for ordering from Amma Ruchulu. Enjoy your authentic homemade pickles! 🍛✨";
  } else if (order.orderStatus === "processing") {
    statusMsg = "Your order is currently being FRESHLY PACKED in our Parvathapur kitchen! 🚚📦";
  }

  const itemsText = order.items.map((i, idx) => `${idx + 1}. *${i.name}* (${i.weight}) x ${i.quantity}`).join("\n");

  const msg = `Namaskaram *${order.customer.fullName}* garu! 🙏
━━━━━━━━━━━━━━━━━━
🍛 *AMMA RUCHULU - ORDER UPDATE*
🆔 *Order ID:* ${order.orderId}
📦 *Status:* *${(order.orderStatus || "Pending").toUpperCase()}*
━━━━━━━━━━━━━━━━━━
${statusMsg}

*Ordered Items:*
${itemsText}
💰 *Total Bill:* ₹${order.totals.grandTotal} (${order.paymentMode.toUpperCase()})

📍 *Store Kitchen:* Sai Aishwarya Colony, Parvathapur, Hyderabad
📞 *Helpline:* +91 8341643180`;

  const url = `https://wa.me/${targetPhone}?text=${encodeURIComponent(msg)}`;
  window.open(url, "_blank");
}

// Open Printable Kitchen Slip Modal
function openKitchenSlipModal(orderId) {
  const order = dashboardState.orders.find(o => o.orderId === orderId);
  if (!order) return;

  const modal = document.getElementById("kitchen-slip-modal");
  const printBody = document.getElementById("print-section");
  if (!modal || !printBody) return;

  const itemsRows = order.items.map((i, idx) => `
    <tr class="border-b">
      <td class="py-2 text-neutral-800 font-medium">${idx + 1}. ${i.name}</td>
      <td class="py-2 text-center font-bold text-red-900">${i.weight}</td>
      <td class="py-2 text-center font-black">x ${i.quantity}</td>
      <td class="py-2 text-right font-mono font-bold">₹${i.unitPrice * i.quantity}</td>
    </tr>
  `).join("");

  printBody.innerHTML = `
    <div class="border border-neutral-300 p-4 rounded-2xl space-y-3 bg-neutral-50 text-xs">
      
      <div class="text-center border-b border-neutral-300 pb-2">
        <h2 class="font-cinzel font-black text-base text-red-900">AMMA RUCHULU (అమ్మ రుచులు)</h2>
        <p class="text-[11px] text-neutral-600">Sai Aishwarya Colony, Road No 1, Parvathapur, Hyderabad - 500098</p>
        <p class="text-[11px] text-neutral-600 font-bold">Helpline: +91 8341643180</p>
      </div>

      <div class="flex justify-between items-start text-xs border-b border-neutral-300 pb-2">
        <div>
          <span class="font-bold text-neutral-900">Order ID: </span>
          <span class="font-mono font-bold text-red-900">${order.orderId}</span>
          <p class="text-[10px] text-neutral-500">${order.timestamp}</p>
        </div>
        <div class="text-right">
          <span class="px-2 py-0.5 rounded text-[10px] font-bold uppercase ${order.orderStatus === 'completed' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}">
            ${(order.orderStatus || 'Pending').toUpperCase()}
          </span>
        </div>
      </div>

      <div>
        <h4 class="font-bold text-neutral-900 mb-0.5">Customer & Delivery Details:</h4>
        <p class="font-semibold text-neutral-800">${order.customer.fullName} (📞 ${order.customer.phone})</p>
        <p class="text-neutral-600 text-[11px] leading-snug">${order.customer.streetAddress}</p>
        <p class="text-neutral-500 text-[10px]">${order.customer.landmark || "Parvathapur"} • Pincode: ${order.customer.pincode || "500098"}</p>
      </div>

      <table class="w-full text-xs">
        <thead class="bg-neutral-200/80 text-neutral-700 font-bold border-b border-neutral-300">
          <tr>
            <th class="py-1.5 text-left">Item Name</th>
            <th class="py-1.5 text-center">Pack</th>
            <th class="py-1.5 text-center">Qty</th>
            <th class="py-1.5 text-right">Price</th>
          </tr>
        </thead>
        <tbody>
          ${itemsRows}
        </tbody>
      </table>

      <div class="border-t border-neutral-300 pt-2 space-y-1 text-xs">
        <div class="flex justify-between text-neutral-600">
          <span>Subtotal</span>
          <span>₹${order.totals.subtotal}</span>
        </div>
        ${order.totals.discountAmount > 0 ? `
          <div class="flex justify-between text-emerald-700 font-semibold">
            <span>Discount</span>
            <span>-₹${order.totals.discountAmount}</span>
          </div>
        ` : ''}
        <div class="flex justify-between text-neutral-600">
          <span>Home Delivery</span>
          <span>${order.totals.deliveryFee === 0 ? 'FREE' : '₹' + order.totals.deliveryFee}</span>
        </div>
        <div class="flex justify-between text-sm font-extrabold text-red-900 border-t border-neutral-300 pt-1.5">
          <span>Total Payable</span>
          <span>₹${order.totals.grandTotal}</span>
        </div>
      </div>

      <div class="p-2.5 bg-neutral-100 rounded-xl border text-[11px] flex justify-between items-center">
        <span>Payment Mode: <strong class="uppercase">${order.paymentMode}</strong></span>
        <span class="font-bold text-neutral-700">${order.status}</span>
      </div>

      <!-- Kitchen Checkboxes -->
      <div class="pt-2 border-t border-dashed border-neutral-300 flex justify-between text-[10px] text-neutral-600 font-bold">
        <span>[ ] Prepared</span>
        <span>[ ] Quality Checked</span>
        <span>[ ] Packed</span>
        <span>[ ] Dispatched</span>
      </div>

    </div>
  `;

  modal.classList.remove("hidden");
  modal.classList.add("flex");
}

function closeKitchenSlipModal() {
  const modal = document.getElementById("kitchen-slip-modal");
  if (modal) {
    modal.classList.add("hidden");
    modal.classList.remove("flex");
  }
}

// Export Orders to CSV Spreadsheet
function exportOrdersToCSV() {
  if (dashboardState.orders.length === 0) {
    alert("No orders available to export.");
    return;
  }

  const headers = ["Order ID", "Date Time", "Status", "Customer Name", "Phone", "Delivery Address", "Items", "Grand Total", "Payment Mode", "Payment Status"];
  const rows = dashboardState.orders.map(o => [
    o.orderId,
    `"${o.timestamp}"`,
    (o.orderStatus || "pending").toUpperCase(),
    `"${o.customer.fullName}"`,
    `"${o.customer.phone}"`,
    `"${o.customer.streetAddress}, ${o.customer.landmark}, ${o.customer.pincode}"`,
    `"${o.items.map(i => `${i.name} (${i.weight}) x${i.quantity}`).join("; ")}"`,
    o.totals.grandTotal,
    o.paymentMode.toUpperCase(),
    `"${o.status}"`
  ]);

  const csvContent = "data:text/csv;charset=utf-8," + [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", `Amma_Ruchulu_Orders_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// Dashboard Toast Helper
function showDashboardToast(msg) {
  const toast = document.createElement("div");
  toast.className = "fixed bottom-5 right-5 z-50 bg-amber-400 text-neutral-950 font-bold text-xs px-4 py-3 rounded-2xl shadow-xl border border-amber-300 flex items-center gap-2 animate-bounce";
  toast.innerHTML = `<span>⚡ ${msg}</span>`;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3500);
}
